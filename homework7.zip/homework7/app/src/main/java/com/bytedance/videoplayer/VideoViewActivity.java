package com.bytedance.videoplayer;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoViewActivity extends AppCompatActivity {
    private VideoView videoView;
    private MediaController mediaController;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoview);
        setTitle("VideoView");
        //获取layout的控件
        videoView = findViewById(R.id.videoView);
        //声明media控制器
//        videoView.setVideoPath(getVideoPath(R.raw.secret));
        mediaController = new MediaController(this);
        //建立videoView和mediaController的关联
        videoView.setMediaController(mediaController);


        // 让videoView获取焦点
        videoView.requestFocus();

    }
    private String getVideoPath(int id){
        return "android.resource://" + this.getPackageName() + "/" + id;
    }
}
