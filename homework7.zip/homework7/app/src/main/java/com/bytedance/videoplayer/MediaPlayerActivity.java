package com.bytedance.videoplayer;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;


import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;


public class MediaPlayerActivity extends AppCompatActivity implements View.OnClickListener,
        MediaPlayer.OnPreparedListener, SeekBar.OnSeekBarChangeListener {
    public static String TAG = "XXL";     // debug使用的标签
    private SurfaceView sv;      // 显示播放媒体的画布
    private MediaPlayer mediaPlayer;      // 媒体播放器
    private SurfaceHolder holder;
    private SeekBar seekBar;              // seekBar对播放器的进度条进行控制
    private TextView tv;                  // 进度条时间显示
    private Button btn_1;                 // 开始按钮
    private Button btn_2;                 // 暂停按钮
    private Button btn_3;                 // 重新开始按钮
//    private int  DataResourceID = R.raw.secret;   // 本地media资源的id
    private static int savedPosition = 0; // 已经记录的进度条的位置
    private Timer timer;
    private TimerTask task;
    private static int Duration = 0;

    private String position_key;
    private static int millSec = 1000;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);//隐藏标题
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);//设置全屏
        if(!isScreenOrientationPortrait(MediaPlayerActivity.this)){
            Log.d(TAG, "当前时竖屏");
            getSupportActionBar().hide();

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
//            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }

        setContentView(R.layout.activity_mediaplayer);

        setTitle("MediaPlayer");

        //三个按钮的声明，并添加点击监听
        btn_1 = findViewById(R.id.btn_start);
        btn_2 = findViewById(R.id.btn_pause);
        btn_3 = findViewById(R.id.btn_restart);
        btn_1.setOnClickListener(this);
        btn_2.setOnClickListener(this);
        btn_3.setOnClickListener(this);

        //mediaPlayer的创建和添加监听
        mediaPlayer = new MediaPlayer(); // 实例化MediaPlayer对象，处于idle状态
        mediaPlayer.setOnPreparedListener(this);


        //seekBar的创建和添加监听
        seekBar = findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(this);

        //进度条的时间
        tv = findViewById(R.id.seekBar_time);
        tv.setSingleLine(true); //一行显示
        tv.setTextColor(getResources().getColor(R.color.colorSeekBar));

        //surfaceView的创建和监听
        sv = findViewById(R.id.surfaceView);
        holder = sv.getHolder();
        holder.addCallback(new PlayerCallBack());
//        //监听media的大小
//        mediaPlayer.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
//            @Override
//            public void onVideoSizeChanged(MediaPlayer mediaPlayer, int i, int i1) {
//                Log.d(TAG, "changeVideoSize");
//                changeVideoSize(mediaPlayer);
//            }
//        });


        // 拿出上次保留的信息 media播放的位置
        if(savedInstanceState != null){
            String content = savedInstanceState.getString(position_key);
            assert content != null;
            savedPosition = Integer.parseInt(content); //记录位置
            Log.d(TAG, "savePosition:"+savedPosition);
            media_play();
        }


    }

//    private void changeVideoSize(MediaPlayer mediaPlayer) {
//        int surfaceWidth =sv.getWidth();
//        int surfaceHeight = sv.getHeight();
//
//        int videoWidth =mediaPlayer.getVideoWidth();
//        int videoHeight = mediaPlayer.getVideoHeight();
//
//        // 根据视频尺寸去计算视频可以在surfaceView中的放大的最大倍数
//        float max;
//        if(getResources().getConfiguration().orientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT){
//        //竖屏模式下按视频宽度计算放大倍数值
//            max = Math.max((float)videoWidth / (float)surfaceWidth, (float)videoHeight / (float)surfaceHeight);
//        }else{
//        //横屏模式下按视频高度计算放大倍数数值
//            max = Math.max((float)videoWidth / (float)surfaceHeight, (float)videoHeight / (float)surfaceWidth);
//        }
//        videoWidth = (int)Math.ceil((float)videoWidth / max);
//        videoHeight = (int)Math.ceil((float)videoHeight / max);
//        Log.d(TAG, "videoSizeChange");
//        sv.setLayoutParams(new RelativeLayout.LayoutParams(videoWidth, videoHeight));
//    }

    public static boolean isScreenOrientationPortrait(Context context) {
        return context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT;
    }
    //监听三个按钮，对mediaPlayer进行控制
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_start:
                media_play();      // 加载资源，然后开始播放开始播放
                break;
            case R.id.btn_pause:
                media_pause();
                break;
            case R.id.btn_restart:
                media_restart();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void media_restart() {
        mediaPlayer.reset(); //reset()方式实现对mediaPlayer的重用，重新回到idle状态
        savedPosition = 0;
        media_play();
    }

    //暂停和继续
    private void media_pause() {
        if(mediaPlayer == null){
            Log.d(TAG, "mediaPlayer实例未创建");
            return;
        }
        if(mediaPlayer.isPlaying()){
            mediaPlayer.pause();
        }
        else{
            mediaPlayer.start();
        }
    }

    // media开始播放
    @RequiresApi(api = Build.VERSION_CODES.N)
    private void media_play(){
        if(mediaPlayer == null)
        {
            Log.d(TAG, "mediaPlayer还没有被实例化");
            return;
        }
        try{
//            mediaPlayer.setDataSource(getResources().openRawResourceFd(DataResourceID));
            mediaPlayer.setDataSource("https://jzvd.nathen.cn/video/1137e480-170bac9c523-0007-1823-c86-de200.mp4");
            // 可以根据资源的类型进行合适的选择，如果是网络上的media，异步可能比较好
            mediaPlayer.prepareAsync();
            addTimer();            // 给media增加一个定时器，同步seekBar
            btn_1.setEnabled(false); //按钮开始按钮设置为无效
        }
        catch (IOException e){
            //Toast.makeText(MediaPlayerActivity.this,"")
            Log.d(TAG,"打开资源失败");
            e.printStackTrace();
        }

    }

    //增加定时器，实现对seekBar和media的同步
    // 需要注意的是，每次进入prepare，都要调用这个函数，必须判单timer是否已经实例化，否则会发生内存泄漏
    private void addTimer() {
        if(timer != null) //之前已经实例化过了，可以接着用
            return;
        timer = new Timer();
        task = new TimerTask() {
            @Override
            public void run() {
                // 必须保证这里mediaPlayer在播放的情况下，才可以覆盖savePosition
                if(mediaPlayer != null && mediaPlayer.isPlaying())
                    savedPosition = mediaPlayer.getCurrentPosition();
                seekBar.setProgress(savedPosition);          //seekBar进度条同步
                tv.setText(formatTime(savedPosition, Duration)); // 时间同步
            }
        };
        timer.schedule(task, 0, millSec);
    }

    //资源准备完毕后开始运行，seekBar进行同步推进
    @Override
    public void onPrepared(final MediaPlayer mediaPlayer) {
//        btn_1.setEnabled(false);
        mediaPlayer.start(); //准备好后开始播放，进入start状态
        mediaPlayer.seekTo(savedPosition);
        Log.d(TAG, "media资源准备完毕，开始执行");
        Duration = mediaPlayer.getDuration();
        seekBar.setMax(mediaPlayer.getDuration());
        mediaPlayer.setLooping(true);
    }


    //格式化字符串，时间格式
    private static String formatTime(int savedPosition, int duration) {
        int sec = savedPosition/1000;
        int dur = duration/1000;
        String res = "";
        if(sec>=60){
            res += (sec/60) + ":" + (sec%60);
        }
        else{
            res += sec;
        }
        res += "/";
        if(dur>=60){
            res += (dur/60) + ":" + (dur%60);
        }
        else{
            res += dur;
        }
        return  res;
    }



    // seekBar的三个监听的事件
    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

    }
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }
    // 鼠标停止拖拽时调用的事件
    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        // 停止拖拽时进度条的位置
        savedPosition = seekBar.getProgress();
        mediaPlayer.seekTo(savedPosition);
    }


    private class PlayerCallBack implements SurfaceHolder.Callback{
        @Override
        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            Log.d(TAG, "创建了surfaceView");
            mediaPlayer.setDisplay(surfaceHolder);
        }

        @Override
        public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
            Log.d(TAG, "surfaceView 发生了改变");

        }

        @Override
        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            Log.d(TAG, "surfaceView 销毁");
        }
    }



    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE ){
            Log.d(TAG, "当前是横屏");
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    // activity被杀死的最后保留savedPosition信息
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        String content = String.valueOf(savedPosition);
        outState.putString(position_key, content);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mediaPlayer != null){
            if(timer != null)
                timer.cancel();        //杀死timer
            mediaPlayer.stop();
            mediaPlayer.release();   // 释放mediaPlayer的资源
            mediaPlayer = null;
        }
        Log.d(TAG, "destroy");
    }
}
