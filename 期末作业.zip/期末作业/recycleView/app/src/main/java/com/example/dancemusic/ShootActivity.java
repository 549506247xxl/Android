package com.example.dancemusic;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.util.Locale;
import java.util.PrimitiveIterator;



/*
    activity的功能是实现视频的上传，包括 本地上传 和 拍摄上传

    1、获取或者验证用户的权限
    2、上传本地视频
    3、拍摄视频并选择上传或取消

 */

public class ShootActivity extends AppCompatActivity{
    private Button btn1;
    private Button btn2;
    private static String TAG = "XXL";
    private String[] permissionsArray = new String[]{
            Manifest.permission.CAMERA, //相机权限
            Manifest.permission.WRITE_EXTERNAL_STORAGE, //写外部文件
            Manifest.permission.READ_EXTERNAL_STORAGE, //读外部文件
            Manifest.permission.RECORD_AUDIO //音频录制
    };
    private int REQUEST_CODE = 277;
    private int REQUEST_CAMERA = 305;
    private File videoPath;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("上传你的视频吧");
        getSupportActionBar().hide();
        setContentView(R.layout.activity_shoot);


        //1、第一件事获取或者验证用户本地文件读写权限和摄像头权限
        if(!checkPermissionAllGranted(permissionsArray)){
            requestPermissions(permissionsArray, REQUEST_CODE);
        }
        initButtons();


    }
    private void initButtons() {
        btn1 = findViewById(R.id.camera);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSystemCamera();
            }
        });

//        btn2 = findViewById(R.id.local);
//        btn2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                loadFromLocal();
//            }
//        });

    }

    /*
    打开系统相机
     */
    private void openSystemCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        String videoName = String.format(Locale.getDefault(),"video_%d.mp4", System.currentTimeMillis());
        videoPath = new File(getExternalCacheDir(), videoName);

        Uri outUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", videoPath);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, outUri);

        startActivityForResult(cameraIntent, REQUEST_CAMERA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CAMERA && resultCode == RESULT_OK){
            Log.d(TAG, "录制成功");
            Toast.makeText(this,"视频拍摄成功"+videoPath,Toast.LENGTH_LONG).show();

            //上传videoPath的video

        }
    }

    private boolean checkPermissionAllGranted(String[] permissions) {
        for (String permission : permissions) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                // 只要有一个权限没有被授予, 则直接返回 false
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_CODE){
            Log.d(TAG, "权限申请回调");
        }
    }
}
