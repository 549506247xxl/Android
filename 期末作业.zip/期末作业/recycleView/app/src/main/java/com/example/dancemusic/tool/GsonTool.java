package com.example.dancemusic.tool;

import com.google.gson.Gson;

public class GsonTool {
    public static VideoItem parseGsonString(String string){
        Gson gson = new Gson();
        return gson.fromJson(string, VideoItem.class);
    }
}
