package com.example.dancemusic;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dancemusic.tool.ApiService;
import com.example.dancemusic.tool.ArticleResponse;
import com.example.dancemusic.tool.VideoItem;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FirstPageActivity extends AppCompatActivity {
    private static String TAG = "XXL_FirstPage";
    private RecyclerView mRecycleView;
    private ImageButton imageButton;
    private List<VideoItem> videos;     //获取信息
    private String baseUrl = "https://beiyou.bytedance.com/";
    private MediaPlayer mediaPlayer;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("一个你从来没见过的憨憨App");
        setContentView(R.layout.activity_page);  //设置布局xml

        mediaPlayer = new MediaPlayer();


        // 1、获取控件对象
        mRecycleView = findViewById(R.id.rv_list);
        // 2、设置布局管理器
        mRecycleView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        // 3、设置默认动画
        mRecycleView.setItemAnimator(new DefaultItemAnimator());

        mRecycleView.setHasFixedSize(true);


        getVideos();  //获取数据video信息，存储到videos中
//        setMyAdapter();
        imageButton = findViewById(R.id.add);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FirstPageActivity.this, ShootActivity.class));
            }
        });
    }

    private void setMyAdapter() {
        if(videos==null)
            return;
        MyVideoAdapter adapter = new MyVideoAdapter(this, videos.size(), videos, mediaPlayer);
        mRecycleView.setAdapter(adapter);
    }

    private void getVideos() {

        Log.d(TAG, "Retrofit in");

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        Log.d(TAG, "Retrofit create");


        ApiService apiService = retrofit.create(ApiService.class);
        apiService.getArticles().enqueue(new Callback<List<VideoItem>>() {
            @Override
            public void onResponse(Call<List<VideoItem>> call, Response<List<VideoItem>> response) {
                Log.d(TAG, "response success");
                if(response.body()!=null){
                        videos = response.body(); //设置数据
                        setMyAdapter();
//                        dataDebug(); //这是一条debug信息
                }
            }

            @Override
            public void onFailure(Call<List<VideoItem>> call, Throwable t) {
                Log.d(TAG, "response error"+t.getMessage());
            }
        });
    }

    private void dataDebug() {
        for(VideoItem item: videos){
            System.out.println("item + " + item.toString());
        }
    }

    //退出该界面的时候，释放mediaPlayer
    @Override
    protected void onDestroy() {
        if(mediaPlayer!=null){
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        super.onDestroy();
    }
}
