package com.example.dancemusic;


import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.dancemusic.tool.VideoItem;

import java.io.IOException;
import java.util.List;

public class MyVideoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static String TAG = "XXL";

    private int video_num;
    private List<VideoItem> videos; //videos信息
    private Context context;       //上下文环境

    private MediaPlayer player;      //只用一个mediaPlayer，可重用
    private SurfaceView surfaceView;
    private SurfaceHolder surfaceHolder;
    private int curr_item = -1; //player当前播放的item序号
    private int last_item = -1; //标记，用来恢复暂停图标
    //构造函数
    public MyVideoAdapter(Context context, int video_num, List<VideoItem> videos, MediaPlayer player){
        this.context = context;
        this.video_num = video_num;
        this.videos = videos;
        this.player = player; //创建的时候，初始化mediaPlayer

    }


    //创建ViewHolder,掌握对item的控制
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        //获得渲染的view
        v = LayoutInflater.from(parent.getContext()).inflate(R.layout.im_list_item, null, false);
        RecyclerView.ViewHolder holder =new MyViewHolder(v);

        return holder;
    }




    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Log.d(TAG, ""+position);
        VideoItem videoItem = videos.get(position);
        //1、设置video名字
        ((MyViewHolder)holder).name.setText(videoItem.getNickName());

        //2、设置视频的预加载图片
        Glide.with(context)
                .load(Uri.parse(videoItem.getAvatar().replace("http://","https://")))
                .into( ((MyViewHolder)holder).topImage);
        ((MyViewHolder)holder).topImage.setVisibility(View.VISIBLE);
        //3、点击surfaceView的时候，开始加载视频资源并播放

        //画布设置监听，视频的播放和暂停
        ((MyViewHolder)holder).sv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MyViewHolder)holder).topImage.setVisibility(View.INVISIBLE);
                setImage((MyViewHolder)holder);
                notifyMedia(position, (MyViewHolder)holder);
            }
        });
    }

    protected void setImage(MyViewHolder holder){
        holder.pauseImage.setVisibility(View.INVISIBLE);
    }

    private void notifyMedia(int position, MyViewHolder item_holder) {
        player.reset(); //点击surfaceView，player进入idle状态

        surfaceHolder = item_holder.sv.getHolder(); //设置当前画布
        surfaceHolder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                Log.d(TAG,"surfaceCreated");
            }
            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
//                    player.setDisplay(holder);
                Log.d(TAG, "surface "+position);
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                Log.d(TAG, "Destroyed");
                //surface destroy的时候，将监听移除，不然会一直存在，占用资源
                holder.removeCallback(this);
                item_holder.pauseImage.setVisibility(View.VISIBLE);
                if(position == curr_item)
                    player.reset();
            }
        });

        curr_item = position;
        player.setDisplay(surfaceHolder); //当前画布和player匹配

        try {
            Log.d(TAG, "media play: " + videos.get(position).getVideoUrl());

            player.setDataSource(context, Uri.parse(videos.get(position).getVideoUrl().replace("http://","https://")));
            player.prepareAsync();        //准备资源
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                //资源准备好后，设置player的画布未当前所在的surfaceView
                 @Override
                public void onPrepared(MediaPlayer mp) {
                    Log.d(TAG, "prepare");
                    mp.start();
                    mp.setLooping(true);
                }
            });

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return video_num;
    }


    private class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        SurfaceView sv;
        ImageView pauseImage;
        ImageView topImage;
        MyViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.video_name);
            sv = v.findViewById(R.id.video_item);
            pauseImage = v.findViewById(R.id.pause);
            topImage = v.findViewById(R.id.top_image);
        }
    }

}
