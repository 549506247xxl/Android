package com.example.dancemusic.tool;


import java.util.List;

public class ArticleResponse {
    public List<VideoItem> videoItemList;


}

