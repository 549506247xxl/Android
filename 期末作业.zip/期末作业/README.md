# 北邮移动互联网技术及其应用期末作业

编写了两个app

视频展示实现方式分别为RecycleView和ViewPager2

可以下载apk进行演示