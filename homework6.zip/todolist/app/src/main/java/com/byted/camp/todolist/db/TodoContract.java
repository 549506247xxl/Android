package com.byted.camp.todolist.db;

import android.provider.BaseColumns;

/**
 * Created on 2019/1/22.
 *
 * @author xuyingyi@bytedance.com (Yingyi Xu)
 */
public final class TodoContract {

    // TODO 定义表结构和 SQL 语句常量

    private TodoContract() {
    }

    //声明创建表项语句
    public static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + NoteEntry.TABLE_NAME + " (" +
                    NoteEntry._ID + " INTEGER PRIMARY KEY," +
                    NoteEntry.COLUMN_1 + " TEXT," +
                    NoteEntry.COLUMN_2 + " TEXT," +
                    NoteEntry.COLUMN_3 + " TEXT)";

    //删除表
    public static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + NoteEntry.TABLE_NAME;


    /* Inner class that defines the table contents */
    public static class NoteEntry implements BaseColumns{

        //表名
        public static final String TABLE_NAME = "NoteTable";

        //列
        public static final String COLUMN_1 = "Date";

        public static final String COLUMN_2 = "state";

        public static final String COLUMN_3 = "content";
    }
}
