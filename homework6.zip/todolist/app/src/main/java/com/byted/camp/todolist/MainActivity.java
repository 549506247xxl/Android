package com.byted.camp.todolist;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.byted.camp.todolist.beans.Note;
import com.byted.camp.todolist.beans.State;
import com.byted.camp.todolist.db.TodoContract;
import com.byted.camp.todolist.db.TodoDbHelper;
import com.byted.camp.todolist.operation.activity.DatabaseActivity;
import com.byted.camp.todolist.operation.activity.DebugActivity;
import com.byted.camp.todolist.operation.activity.SettingActivity;
import com.byted.camp.todolist.ui.NoteListAdapter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_ADD = 1002;
    public static String TAG = "Note";
    private RecyclerView recyclerView;
    private NoteListAdapter notesAdapter;
//    private HandlerThread operate_database;
//    private WorkHandler workHandler;
    private TodoDbHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // 点击悬浮的按钮，跳转到写笔记的界面
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
        // startActivityForResult 当前Activity跳转到另一个Activity，当关闭时，向当前Activity传回数据
                startActivityForResult(
                        new Intent(MainActivity.this, NoteActivity.class),
                        REQUEST_CODE_ADD);
            }
        });


//        //创建一个Handler线程，轮询消息
//        operate_database = new HandlerThread("operate_database");
//        operate_database.start();
//
//        //对消息进行处理
//        workHandler = new WorkHandler(operate_database.getLooper());
        //创建DbHelper
        dbHelper = new TodoDbHelper(this);


        recyclerView = findViewById(R.id.list_todo);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false));
        recyclerView.addItemDecoration(
                new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        notesAdapter = new NoteListAdapter(new NoteOperator() {
            @Override
            public void deleteNote(Note note) {
                MainActivity.this.deleteNote(note);
                // 更新列表内容
                notesAdapter.refresh(loadNotesFromDatabase());
            }

            @Override
            public void updateNote(Note note) {
                MainActivity.this.updateNode(note);
                //更新列表内容
                notesAdapter.refresh(loadNotesFromDatabase());
            }
        });
        recyclerView.setAdapter(notesAdapter);

        notesAdapter.refresh(loadNotesFromDatabase());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.action_settings:
                startActivity(new Intent(this, SettingActivity.class));
                return true;
            case R.id.action_debug:
                startActivity(new Intent(this, DebugActivity.class));
                return true;
            case R.id.action_database:
                startActivity(new Intent(this, DatabaseActivity.class));
                return true;
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD
                && resultCode == Activity.RESULT_OK) {
            notesAdapter.refresh(loadNotesFromDatabase());
        }
    }

    private List<Note> loadNotesFromDatabase() {
        // TODO 从数据库中查询数据，并转换成 JavaBeans

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                TodoContract.NoteEntry._ID,
                TodoContract.NoteEntry.COLUMN_1,
                TodoContract.NoteEntry.COLUMN_2,
                TodoContract.NoteEntry.COLUMN_3
        };

        Cursor cursor = db.query(
                TodoContract.NoteEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        ArrayList<Note> notes = new ArrayList<>();
        while(cursor.moveToNext()){
            long itemID = cursor.getLong(cursor.getColumnIndexOrThrow(TodoContract.NoteEntry._ID));
            String column_1 = cursor.getString(cursor.getColumnIndex(TodoContract.NoteEntry.COLUMN_1));
            String column_2 = cursor.getString(cursor.getColumnIndex(TodoContract.NoteEntry.COLUMN_2));
            String column_3 = cursor.getString(cursor.getColumnIndex(TodoContract.NoteEntry.COLUMN_3));

            Log.d(TAG, "item: "+ itemID);
            Note note = new Note(itemID);

            Log.d(TAG, "Date: "+ column_1);
            note.setDate(new Date(column_1));

            Log.d(TAG, "State");
    //        note.setState();
            note.setContent(column_3);

            notes.add(note);
        }

        return notes;
    }

    private void deleteNote(Note note) {
        // TODO 删除数据
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = TodoContract.NoteEntry._ID + " = ?";
        String[]  selectionArg = {""+note.id};

        int deleteRow = db.delete(TodoContract.NoteEntry.TABLE_NAME, selection, selectionArg);
        Log.d(TAG,"deleteNode"+deleteRow);
    }

    private void updateNode(Note note) {
        // 更新数据
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String selection = TodoContract.NoteEntry._ID + " = ?";
        String[] selectionArgs = { ""+note.id };

        ContentValues values = new ContentValues();
 //       values.put(TodoContract.NoteEntry.COLUMN_1, new Date().toString());
        values.put(TodoContract.NoteEntry.COLUMN_2, note.getDate().toString());
        int count = db.update(
                TodoContract.NoteEntry.TABLE_NAME,
                values,
                selection,
                selectionArgs);
        Log.d(TAG, "update:" + count);
    }

}
